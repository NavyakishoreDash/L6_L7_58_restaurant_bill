========================================================================
LAB 6: CODE AND BRANCH COVERAGE - SUBMISSION INFORMATION
========================================================================

STUDENT DETAILS:
Name: Navyakishore Dash
SRN: PES2UG24CS307
Course: UE23CS301 - Software Engineering
Department: Department of Computer Science and Engineering
Institution: PES University

GITHUB REPOSITORY LINK (Copy-paste this into the form):
https://github.com/NavyakishoreDash/L6_L7_58_restaurant_bill
(Base Upstream: https://github.com/SETAPESU26/L6_L7_58_restaurant_bill)

========================================================================
SUMMARY OF LAB 6 DELIVERABLES & COVERAGE ACHIEVED
========================================================================

1. Target Module: restaurant_bill.py
   - bill_total(section, food_total, guests, is_happy_hour)
   - split_bill(total, people, tip_percent)
   - table_wait(party_size, free_tables, has_reservation)

2. Test Suite: test_restaurant_bill.py
   - 21 comprehensive test cases exercising all decision branches and boundary conditions.
   - Handled all exception cases (ValueError for unknown section, invalid orders, invalid people, negative tips).

3. Coverage Results (pytest-cov):
   ========================================================================
   Name                 Stmts   Miss Branch BrPart  Cover   Missing
   ------------------------------------------------------------------------
   restaurant_bill.py      33      0     22      0   100%
   ------------------------------------------------------------------------
   TOTAL                   33      0     22      0   100%
   ========================================================================
   - Statement Coverage: 100% (33/33 statements)
   - Branch Coverage: 100% (22/22 branches)
   - Test Results: 21 passed in 1.35s

4. Documentation:
   - PES2UG24CS307_NavyakishoreDash_LAB6.docx: Word document with screenshots, main python code, test code, and decision table.
   - PES2UG24CS307_NavyakishoreDash_LAB6.pdf: PDF document version.
   - screenshots/SS_lab6_coverage.png: Terminal execution screenshot.
