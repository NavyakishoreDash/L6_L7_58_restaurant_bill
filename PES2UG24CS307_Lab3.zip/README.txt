========================================================================
LAB 3: COMPONENT MODELLING & ARCHITECTURAL PATTERN SELECTION
========================================================================

STUDENT DETAILS:
Name: Navyakishore Dash
SRN: PES2UG24CS307
Course: UE23CS301 - Software Engineering
Department: Department of Computer Science and Engineering
Institution: PES University

ASSIGNED SCENARIO:
Self-Service Coffee Kiosk System (3 Coffee Types, 2 Sizes, Credit Card Only, Receipt Printer)

SELECTED ARCHITECTURE:
Layered Architecture (3-Tier: Presentation, Business, Data)

GITHUB REPOSITORY LINK:
https://github.com/NavyakishoreDash/L6_L7_58_restaurant_bill
(Directory: LAB3)

========================================================================
LAB 3 DELIVERABLES SUMMARY
========================================================================
1. Component Diagram:
   - diagrams/coffee_kiosk_component_diagram.png (High-Res 300 DPI)
   - diagrams/coffee_kiosk_component_diagram.pdf (Vector PDF)
   - Features: 5 components, 4 interfaces (Ball & Socket notation), ports, and layer packages.

2. Written Justification (Strict 1-Page Document):
   - PES2UG24CS307_NavyakishoreDash_LAB3_Justification.docx (Word Document)
   - PES2UG24CS307_NavyakishoreDash_LAB3_Justification.pdf (PDF Document)
   - Includes: Architectural Choice, Two Reasons, Security Advantage, Performance Benefit.

3. Comprehensive Full Lab Report:
   - PES2UG24CS307_NavyakishoreDash_LAB3_Report.docx
   - PES2UG24CS307_NavyakishoreDash_LAB3_Report.pdf
   - Includes: Full background, component dictionary, interface contract tables, and embedded diagrams.
