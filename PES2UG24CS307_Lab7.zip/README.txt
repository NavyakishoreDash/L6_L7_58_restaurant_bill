========================================================================
LAB 7: FUZZING FOR INPUT VALIDATION BUGS - SUBMISSION INFORMATION
========================================================================

STUDENT DETAILS:
Name: Navyakishore Dash
SRN: PES2UG24CS307
Course: UE23CS301 - Software Engineering
Department: Department of Computer Science and Engineering
Institution: PES University

GITHUB REPOSITORY LINKS:
Primary Project Repository:
https://github.com/NavyakishoreDash/L6_L7_58_restaurant_bill
(Fork of: https://github.com/SETAPESU26/L6_L7_58_restaurant_bill)

========================================================================
SUMMARY OF CHANGED CODES & LAB 7 DELIVERABLES
========================================================================

1. restaurant_bill_parser.py (Changed & Fixed Code):
   - clean_dish_name(name): Hardened with isinstance(name, str) validation to prevent AttributeError on None or non-string inputs. Safely strips markers (*, #, ~) and whitespace before title-casing.
   - parse_item_prices(text): Hardened with type checking and safe token processing using try-except (ValueError, TypeError), gracefully handling empty strings, non-numeric tokens, and trailing delimiters while parsing valid integers.
   - split_amount(text): Hardened against missing/extra slashes by validating len(parts) == 2, explicitly checking people > 0 to prevent ZeroDivisionError, and catching (ValueError, TypeError, ZeroDivisionError).

2. test_restaurant_bill_parser.py (Completed Hypothesis Fuzz Test Suite):
   - Implemented @given(st.text() | st.none()) property-based tests for all three functions.
   - Used try-except pattern with assert False to catch and report unexpected crashes.

3. Reports & Documentation:
   - PES2UG24CS307_NavyakishoreDash_LAB7.pdf: Complete PDF report with SS1-SS4 screenshots and reflection answers.
   - PES2UG24CS307_NavyakishoreDash_LAB7.docx: Formatted Word document with all test cases, bugs identified, and fixes.
   - screenshots/: High-resolution terminal capture images (SS1 to SS4).
