========================================================================
LAB 1: REQUIREMENTS ENGINEERING & UML USE-CASE MODELLING
========================================================================

STUDENT DETAILS:
Name: Navyakishore Dash
SRN: PES2UG24CS307
Course: UE23CS301 - Software Engineering
Department: Department of Computer Science and Engineering
Institution: PES University

PROBLEM STATEMENT #13:
Healthcare & Telemedicine: Patient Health Record Consent Management System

GITHUB REPOSITORY LINK:
https://github.com/NavyakishoreDash/L6_L7_58_restaurant_bill
(Directory: LAB1)

========================================================================
LAB 1 DELIVERABLES SUMMARY
========================================================================
1. Complete Requirements Table:
   - Exactly 5 Functional Requirements (FR-001 to FR-005)
   - 2 Non-Functional Requirements (NFR-001 & NFR-002)
   - Formatted with ID, Type, Description, Priority, Acceptance Criteria, Rationale.

2. UML Use-Case Diagram:
   - diagrams/patient_consent_use_case_diagram.png (High-Res 300 DPI)
   - diagrams/patient_consent_use_case_diagram.pdf (Vector PDF)
   - Features: All primary actors (Patient, Clinic Admin, Doctor, Audit System), core use cases,
     explicit <<include>> relationships, and <<extend>> relationships.

3. Use-Case Flow Specification (Core Use Case UC-01):
   - Preconditions, Postconditions, Main Success Scenario (13 steps),
     Alternate Flows (A1 Granular Exclusion, A2 Emergency Trauma Override),
     Exception Flows (E1 Invalid License, E2 Authentication Timeout).

4. Lab 1 Reports:
   - PES2UG24CS307_NavyakishoreDash_LAB1_Report.pdf (Full Academic PDF Report)
   - PES2UG24CS307_NavyakishoreDash_LAB1_Report.docx (Full Academic Word Document)
   - PES2UG24CS307_NavyakishoreDash_LAB1_UseCase_Spec.docx (Dedicated Use-Case Specification)
